/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoa;

/**
 *
 * @author nicol
 */
import java.util.Stack;

public class TotalPuntos {
    public static void main(String[] args) {
        // Crear una pila llamada "TotalPuntos" para simular el total de puntos anotados por los equipos
        Stack<Integer> TotalPuntos = new Stack<>();
        TotalPuntos.push(40); // puntos del equipo America De cali
        TotalPuntos.push(35); // puntos del equipo SantaFe
        TotalPuntos.push(30); // puntos del equipo Atletico Nacional
        TotalPuntos.push(29); // puntos del equipo Pereira
        TotalPuntos.push(27); // puntos del equipo Deportivo Cali
        TotalPuntos.push(27); // puntos del equipo Independiente Medellin
        TotalPuntos.push(25); // puntos del equipo Cor
        TotalPuntos.push(23); // puntos del equipo Equidad
        TotalPuntos.push(23); // puntos del equipo Millonarios
        TotalPuntos.push(22); // puntos del equipo Llaneros Femenina
        TotalPuntos.push(22); // puntos del equipo Junior
        TotalPuntos.push(21); // puntos del equipo Boyacá Chicó Femenina	
        TotalPuntos.push(20); // puntos del equipo Huila
        TotalPuntos.push(20); // puntos del equipo RST
        TotalPuntos.push(13); // puntos del equipo Pasto
        TotalPuntos.push(12); // puntos del equipo Bucaramanga
        TotalPuntos.push(6); // puntos del equipo Tolima

        // Calcular los puntos anotados en este año 2023
        int puntos = 0;
        while (!TotalPuntos.isEmpty()) {
            puntos += TotalPuntos.pop();
        }

        // Mostrar los puntos totales anotados en la LigaBetPlayFem 2023
        System.out.println("El total de puntos anotados por los equipos: " + puntos + " puntos");
    }
}