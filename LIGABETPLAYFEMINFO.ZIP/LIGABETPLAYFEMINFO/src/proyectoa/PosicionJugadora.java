/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoa;

/**
 *
 * @author nicol
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

class JugadoraDeFutbol {
    String nombre;
    String posicion;

    public JugadoraDeFutbol(String nombre, String posicion) {
        this.nombre = nombre;
        this.posicion = posicion;
    }
}
// método de iteracción
public class PosicionJugadora {
    public static void main(String[] args) {
        // Crear una lista con las jugadoras de fútbol
        List<JugadoraDeFutbol> jugadoras = new ArrayList<>();
        jugadoras.add(new JugadoraDeFutbol("Maria", "Delantera"));
        jugadoras.add(new JugadoraDeFutbol("Laura", "Defensa"));
        jugadoras.add(new JugadoraDeFutbol("Ana", "Centrocampista"));

        // Método para buscar una jugadora de fútbol por su posición
        String posicionJugadoraBuscada = "Defensa";
        Optional<JugadoraDeFutbol> jugadoraBuscada = buscarJugadoraPorPosicion(jugadoras, posicionJugadoraBuscada);

        // Mostrar información de la jugadora de fútbol buscada
        if (jugadoraBuscada.isPresent()) {
            JugadoraDeFutbol jugadoraEncontrada = jugadoraBuscada.get();
            System.out.println(jugadoraEncontrada.nombre + " juega como " + jugadoraEncontrada.posicion);
        } else {
            System.out.println("No se encontró ninguna jugadora en la posición " + posicionJugadoraBuscada);
        }
    }

    // Método para buscar una jugadora de fútbol por su posición
    private static Optional<JugadoraDeFutbol> buscarJugadoraPorPosicion(List<JugadoraDeFutbol> listaJugadoras, String posicion) {
        return listaJugadoras.stream()
                .filter(jugadora -> jugadora.posicion.equals(posicion))
                .findFirst();
    }
}