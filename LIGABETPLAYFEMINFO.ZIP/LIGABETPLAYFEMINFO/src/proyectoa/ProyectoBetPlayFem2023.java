/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoa;

/**
 *
 * @author nicol
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

// Definición de la clase VentanaAutenticacion
class VentanaAutenticacion extends JFrame implements ActionListener {
    // Declaración de los componentes de la ventana
    private JTextField usuarioField;  // Campo de texto para el usuario
    private JPasswordField contraseñaField;  // Campo de texto para la contraseña
    private JButton botonAutenticar;  // Botón de autenticación
    private JButton botonDatos;
    private boolean autenticado = false;  // Variable que indica si el usuario ha sido autenticado

    // Constructor de la ventana de autenticación
    public VentanaAutenticacion() {
        // Configuración de la ventana
        setTitle("INFOBETPLAYFEM2023");
        setSize(600, 300);  // Tamaño aumentado
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(246, 186, 202 )); // Cambia el color de fondo 

        // Inicialización de los componentes
        usuarioField = new JTextField(10);
        contraseñaField = new JPasswordField(10);
        botonAutenticar = new JButton("Ingresar");
        botonDatos = new JButton("Datos");  // Inicializa el botón "Datos"
        
        
        
        // Configuración del layout
        setLayout(new GridBagLayout()); // Usamos un GridBagLayout para mejor control de posición

        // Configuración de GridBagConstraints
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 2, 5); // Margen entre componentes

        // Agrega un JLabel con el título
        JLabel titulo = new JLabel("A continuación verás datos generales de la LIGA FEMENINA BETPLAY 2023");
        gbc.gridx = 0;
        gbc.gridy = 0; // Puedes ajustar este valor para controlar la posición vertical del título
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        add(titulo, gbc);

        // Agregar componente: Usuario
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST; // Alinea a la izquierda
        add(new JLabel("Usuario: "), gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST; // Alinea a la izquierda
        add(usuarioField, gbc);

        // Agregar componente: Contraseña
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST; // Alinea a la izquierda
        add(new JLabel("Contraseña: "), gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST; // Alinea a la izquierda
        add(contraseñaField, gbc);

        // Agregar componente: Botón de Autenticar
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 3; // El botón ocupará 2 columnas
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        add(botonAutenticar, gbc);

        // Agregar componente: Botón Datos
        gbc.gridx = 0;
        gbc.gridy = 4;  // Ajusta la posición según tus preferencias
        gbc.gridwidth = 2; // El botón ocupará 2 columnas
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        add(botonDatos, gbc);

        
        // Configuración del ActionListener para el botón de autenticar
        botonAutenticar.addActionListener(this);
        botonDatos.addActionListener(this);
        
    }

    // Método para verificar si el usuario está autenticado
    public boolean estaAutenticado() {
        return autenticado;
    }
    


    // Método que se ejecuta cuando se presiona el botón de autenticar
    @Override
public void actionPerformed(ActionEvent e) {
    if (e.getSource() == botonAutenticar) {
        String usuario = usuarioField.getText();
        String contraseña = new String(contraseñaField.getPassword());

        // Verifica las credenciales
        if (validarCredenciales(usuario, contraseña)) {
            autenticado = true;
            dispose(); // Cierra la ventana
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas. Intente de nuevo.");
        }
    } else if (e.getSource() == botonDatos) {
        JOptionPane.showMessageDialog(this, "Usuario: LIGA y Contraseña: 2023", "CREDENCIALES DE ACCESO", JOptionPane.INFORMATION_MESSAGE);
    }
}



    // Método para validar las credenciales (usuario y contraseña)
    private boolean validarCredenciales(String usuario, String contraseña) {
        return usuario.equals("LIGA") && contraseña.equals("2023");
    }
}


public class ProyectoBetPlayFem2023 {
    public static void main(String[] args) {
        VentanaAutenticacion ventanaAutenticacion = new VentanaAutenticacion();
        ventanaAutenticacion.setVisible(true);

        while (!ventanaAutenticacion.estaAutenticado()) {
            try {
                Thread.sleep(1000); // Esperar 1000 milisegundos antes de volver a verificar
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("BIENVENIDO\n");

        int opcion;
        Scanner scr = new Scanner(System.in);

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Datos de la Liga BetPlayFem2023");
            System.out.println("2. Equipos que clasifican para la final");
            System.out.println("3. Datos sobre el club");
            System.out.println("4. Total de puntos anotados en la LigaBetPlayFemenina2023");
            System.out.println("5. Posicion jugadora");
            System.out.println("6. Estadios de Colombia");
            System.out.println("7. Creditos");
            System.out.print("Seleccione una opcion: ");
            opcion = scr.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("DATOS DE LA LIGABETPLAYFEM2023 :");
                    Equipos.main(args);
                    break;
                case 2:
                    System.out.println("\n\nEQUIPOS QUE CLASIFICAN PARA LA FINAL:");
                    Posiciones.main(args);
                    break;
                case 3:
                    System.out.println("\n\nDATOS SOBRE EL CLUB:");
                    Club.main(args);
                    break;
                case 4:
                    System.out.println("\n\nTOTAL PUNTOS ANOTADOS EN LA LIGABETPLAYFEMENINA2023:");
                    TotalPuntos.main(args);
                    break;
                case 5:
                    System.out.println("\n\nRETO MÉTODOS ITERACIÓN:");
                    PosicionJugadora.main(args); // Llamada a RetoMetodosIteracion
                    break;
                    case 6:
                    System.out.println("\n\nESTADIOS DE COLOMBIA:");
                    EstadiosColombia.main(args); // Llamada a RetoMetodosIteracion
                    break;
                case 7:
                    System.out.println("\n\n NICOLE DAYANA PAJARITO SANTAMARIA\n POLITECNICO INTERNACIONAL\n DESARROLLO DE SOFTWARE\n CILO III");
                    break;
                default:
                    System.out.println("Opcion no valida. Por favor, seleccione una opcion valida.");
                    break;
            }

        } while (opcion != 7);
    }
}


