/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoa;

/**
 *
 * @author nicol
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Club {
    public static void main(String[] args) {
        // Crear una "Lista Genérica Diversa" para los Equipos finalistas
        List<Map<String, Object>> participantesLiga = new ArrayList<>();
        
        System.out.println();//agrega una línea en blanco
        
        // Agregar información de participantes
        Map<String, Object> participante1 = new HashMap<>();
        participante1.put("equipo", "America De Cali");
        participante1.put("presidente", "Marcela Gomez");
        participante1.put("director", "Carlos Hernandez");
        participante1.put("goles", 11);
        participantesLiga.add(participante1);

        Map<String, Object> participante2 = new HashMap<>();
        participante2.put("equipo", "Atletico Nacional");
        participante2.put("presidente", "Mauricio Navarro");
        participante2.put("director", "Jorge Barreneche");
        participante2.put("goles", 8);
        participantesLiga.add(participante2);

        Map<String, Object> participante3 = new HashMap<>();
        participante3.put("equipo", "SantaFe");
        participante3.put("presidente", "Eduardo Mendez");
        participante3.put("director", "Omar Ramirez");
        participante3.put("goles", 20);
        participantesLiga.add(participante3);
        
        Map<String, Object> participante4 = new HashMap<>();
        participante4.put("equipo", "Deportivo Cali ");
        participante4.put("presidente", "Marcos Caicedo");
        participante4.put("director", "Sergio Angulo");
        participante4.put("goles", 8);
        participantesLiga.add(participante4);
        
        Map<String, Object> participante5 = new HashMap<>();
        participante5.put("equipo", "Millonarios");
        participante5.put("presidente", "Enrrique Camacho");
        participante5.put("director", "Alvaro Anzola");
        participante5.put("goles", 8);
        participantesLiga.add(participante5);


        // Mostrar información de Equipo  AmericaDeCali
        Map<String, Object> infoAmerica = participantesLiga.get(0); 
        System.out.println("Informacion del primer equipo finalista:");
        System.out.println("Equipo: " + infoAmerica.get("equipo"));
        System.out.println("Presidente: " + infoAmerica.get("presidente"));
        System.out.println("Director Tecnico: " + infoAmerica.get("director"));
        System.out.println("Total Goles: " + infoAmerica.get("goles"));
        
        System.out.println();
        // Mostrar información de Equipo  Atlético Nacional
        Map<String, Object> infoNacional = participantesLiga.get(1); 
        System.out.println("Informacion del segundo equipo finalista:");
        System.out.println("Equipo: " + infoNacional.get("equipo"));
        System.out.println("Presidente: " + infoNacional.get("presidente"));
        System.out.println("Director Tecnico: " + infoNacional.get("director"));
        System.out.println("Total Goles: " + infoNacional.get("goles"));
        
        System.out.println();
        // Mostrar información de Equipo  SantaFe
        Map<String, Object> infoSantaFe = participantesLiga.get(2); 
        System.out.println("Informacion del tercer equipo finalista:");
        System.out.println("Equipo: " + infoSantaFe.get("equipo"));
        System.out.println("Presidente: " + infoSantaFe.get("presidente"));
        System.out.println("Director Tecnico: " + infoSantaFe.get("director"));
        System.out.println("Total Goles: " + infoSantaFe.get("goles"));
        
        System.out.println();
        // Mostrar información de Equipo  DeportivoCali
        Map<String, Object> infoCali= participantesLiga.get(3); 
        System.out.println("Informacion del cuarto equipo finalista:");
        System.out.println("Equipo: " + infoCali.get("equipo"));
        System.out.println("Presidente: " + infoCali.get("presidente"));
        System.out.println("Director Tecnico: " + infoCali.get("director"));
        System.out.println("Total Goles: " + infoCali.get("goles"));
        
        System.out.println();
        // Mostrar información de Equipo Millonarios
        Map<String, Object> infoMillos = participantesLiga.get(4); 
        System.out.println("Informacion del quinto equipo finalista:");
        System.out.println("Equipo: " + infoMillos.get("equipo"));
        System.out.println("Presidente: " + infoMillos.get("presidente"));
        System.out.println("Director Tecnico: " + infoMillos.get("director"));
        System.out.println("Total Goles: " + infoMillos.get("goles"));
    }
}
