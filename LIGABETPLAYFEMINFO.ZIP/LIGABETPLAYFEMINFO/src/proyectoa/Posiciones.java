/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoa;

/**
 *
 * @author nicol
 */
import java.util.ArrayList;
import java.util.List;

public class Posiciones {
    public static void main(String[] args) {
        // Crear una "Lista Posición Ordinal" para los finalistas de la LigaBetPlayfem2023
        List<String> finalistas = new ArrayList<>();
        finalistas.add("America");
        finalistas.add("SantaFe");
        finalistas.add("Atletico Nacional");
        finalistas.add("Pereira");
        finalistas.add("Deportaivo Cali");

        System.out.println();//agrega una línea en blanco


        // Mostrar cada nombre con su posición en el equipo
        for (int i = 0; i < finalistas.size(); i++) {
            int posicion = i + 1; // Sumar 1 para que las posiciones comiencen desde 1
            String nombre = finalistas.get(i);
            System.out.println("Finalista " + posicion + ": " + nombre);
        }
    }
}
