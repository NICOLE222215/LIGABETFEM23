/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoa;

/**
 *
 * @author nicol
 */
import java.util.ArrayList;
import java.util.List;

public class Equipos {
    public static void main(String[] args) {
        // Crear una lista tipada para almacenar cadenas de caracteres
        List<String> listaTipada = new ArrayList<>();
        // Agregar elementos a la lista
        listaTipada.add("America De cali");
        listaTipada.add("Deportivo Cali");
        listaTipada.add("Independiente SantaFe");
        listaTipada.add("Millonarios");
        listaTipada.add("Independiente Medellin");
        listaTipada.add("Atletico Nacional");
        listaTipada.add("Deportivo Pereira");
        listaTipada.add("Junior FC");
        listaTipada.add("Deportes Tolima");
        listaTipada.add("La Equidad");
        listaTipada.add("Real Santander");
        listaTipada.add("Boyaca Chico");
        
        System.out.println();//agrega una línea en blanco
        
        // Imprimir los elementos de la lista
        System.out.println("Equipos de la Liga BetPlay Femenina 2023 :\n"); 
        for (String elemento : listaTipada) {
            System.out.println(elemento);
        }
        
    }
}
