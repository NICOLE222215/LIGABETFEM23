/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoa;

/**
 *
 * @author nicol
 */
import java.util.ArrayList;
import java.util.List;

public class EstadiosColombia {
    public static void main(String[] args) {
        // Crear una "Lista Genérica" para almacenar los estadios de Colombia
        List<String> EstadiosColombia = new ArrayList<>();
        
        EstadiosColombia.add("Estadio Monumental de Palmaseca");
        EstadiosColombia.add("Metropolitano Roberto Melendez ");
        EstadiosColombia.add("Atanasio Girardot");
        EstadiosColombia.add("Nemesio Camacho El Campín");
        EstadiosColombia.add("Olimpico Pascual Guerrero");

        // Mostrar los nombres de todos los estadios

        for (String Estadios : EstadiosColombia) {
            System.out.println(Estadios);
        }
    }
}