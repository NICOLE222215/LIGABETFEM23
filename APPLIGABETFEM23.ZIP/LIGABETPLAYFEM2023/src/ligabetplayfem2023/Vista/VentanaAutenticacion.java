/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ligabetplayfem2023.Vista;

/**
 *
 * @author nicol
 */
import ligabetplayfem2023.Modelo.Equipo;
import javax.swing.*;  // Crear interfaces graficas
import java.awt.*;     // Importa clases para manejar componentes gráficos 
import java.awt.event.ActionEvent;   // Importa clases para manejar eventos
import java.awt.event.ActionListener;  // Importa clases para manejar eventos de acción
import ligabetplayfem2023.Controlador.AmericaDeCali;
import ligabetplayfem2023.Controlador.AtleticoNacional;
import ligabetplayfem2023.Controlador.DeportivoCali;
import ligabetplayfem2023.Controlador.DeportivoPereira;
import ligabetplayfem2023.Controlador.IndependienteSantaFe;

public class VentanaAutenticacion { 

    private JFrame frame; // Se declara la variable ´frame´ de tipo JFrame. Para representar interfaz grafica

    // Constructor de la clase
    public VentanaAutenticacion() {
        // Crear una instacia JFrame para la ventana de autenticación
        frame = new JFrame("Liga BetPlay - Futbol Femenino Colombiano 2023");
        //configura la accion de cierre de ventana en la X
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //establece el tamaño de la ventana de autenticacion
        frame.setSize(500, 300);
        
        

        // Crear un JPanel que cubra toda la ventana y configurar el color de fondo
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {//se llama este metodo para pintar el panel 
                super.paintComponent(g);// para mantener la funcionalidad adicional que se haga
                g.setColor(new Color(99, 221, 101)); // configuracion de color
                // Dibuja un rectángulo del tamaño del panel que será el fondo que vamos a pintar
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

            
            panelFondo.setLayout(new GridBagLayout());  // Establece el layout del panel como GridBagLayout
            //Es un gestor de diseño flexible 
            GridBagConstraints gbc = new GridBagConstraints();  // Crea un objeto para las restricciones del layout
            gbc.insets = new Insets(5, 5, 5, 5);  // Se establecen margénes 
            
            // Etiqueta del título
        JLabel labelTitulo = new JLabel("BIENVENIDO A LA APP LIGA FEMENINA BETPLAY 2023");
        labelTitulo.setFont(new Font("Arial", Font.BOLD, 15)); // Establece fuente y tamaño
        labelTitulo.setForeground(Color.BLACK); // Color del texto
        //Establece la posición de la etiqueta en la cuadrícula del GridBagLayout. En este caso, se coloca en la columna 0 y fila 0.
        gbc.gridx = 0;  // Posición en la columna 0
        gbc.gridy = 0;  // Posición en la fila 0
        gbc.gridwidth = 3; // Ocupar dos columnas
        gbc.anchor = GridBagConstraints.PAGE_START; // Alinear al principio del panel

        panelFondo.add(labelTitulo, gbc);  // Agrega la etiqueta al panelFondo

        gbc.insets = new Insets(25, 10, 0, 5); // Establece márgenes para los siguientes componentes

        // Etiqueta y campo de texto para el nombre de usuario
        JLabel labelUsuario = new JLabel("USUARIO:");  // Crea una etiqueta con el texto "Usuario:"
        labelUsuario.setFont(new Font("Arial", Font.BOLD, 15)); // Establece fuente y tamaño
        labelUsuario.setForeground(new Color(1, 21, 6)); // Establece el color del texto como blanco

        JTextField campoUsuario = new JTextField(20);  // Crea un campo de texto con una longitud inicial de 20 caracteres

        gbc.gridx = 0;  // Posición en la columna 0
        gbc.gridy = 1;  // Ajustado a la siguiente fila
        gbc.gridwidth = 1; // Restaura el valor a 1 (para que no ocupe más de una columna)
        panelFondo.add(labelUsuario, gbc);  // Agrega la etiqueta al panelFondo

        gbc.gridx = 1;  // Posición en la columna 1
        gbc.gridy = 1;  // Ajustado a la siguiente fila
        panelFondo.add(campoUsuario, gbc);  // Agrega el campo de texto al panelFondo


        // Etiqueta y campo de texto para la contraseña
        JLabel labelContraseña = new JLabel("CONTRASEÑA:");  // Crea una etiqueta con el texto "Contraseña:"
        labelContraseña.setFont(new Font("Arial", Font.BOLD, 15)); // Establece fuente y tamaño
        labelContraseña.setForeground(new Color(1, 21, 6)); // Establece el color del texto como blanco

        JPasswordField campoContraseña = new JPasswordField(20);  // Crea un campo de contraseña con una longitud inicial de 20 caracteres

        gbc.gridx = 0;  // Posición en la columna 0
        gbc.gridy = 2;  // Ajustado a la siguiente fila
        panelFondo.add(labelContraseña, gbc);  // Agrega la etiqueta al panelFondo

        gbc.gridx = 1;  // Posición en la columna 1
        gbc.gridy = 2;  // Ajustado a la siguiente fila
        panelFondo.add(campoContraseña, gbc);  // Agrega el campo de contraseña al panelFondo


        // Botón para ingresar
        JButton botonIngresar = new JButton("Ingresar");  // Crea un botón con el texto "Ingresar"

        botonIngresar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();  // Obtiene el texto del campo de usuario
                String contraseña = new String(campoContraseña.getPassword());  // Obtiene la contraseña como texto

                if (autenticar(usuario, contraseña)) {  // Verifica la autenticación
                    mostrarVentanaMenu();  // Muestra la ventana del menú
                    frame.dispose();  // Cierra la ventana de autenticación
                } else {
                    // Muestra un mensaje de error si la autenticación falla
                    JOptionPane.showMessageDialog(frame, "Usuario o contraseña incorrectos", "Error de Autenticación", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        botonIngresar.setBackground(new Color(92, 239, 128)); // Cambiar el color del botón
        
        JButton BotonDatos = new JButton("Datos de Ingreso");

        BotonDatos.addActionListener(e -> {
        JPanel panel = new JPanel(new GridLayout(4, 1)); // Cambio a GridLayout

        JLabel labelLIGA = new JLabel("Usuario: LIGA");
        labelLIGA.setForeground(Color.BLACK);

        JLabel label2023 = new JLabel("Contraseña: 2023");
        label2023.setForeground(Color.BLACK);

        panel.setBackground(new Color(245, 143, 188));
        panel.add(labelLIGA);
        panel.add(label2023);

        JOptionPane.showMessageDialog(null, panel, "Datos de Ingreso", JOptionPane.PLAIN_MESSAGE);
        
        });
        BotonDatos.setBackground(new Color(254, 181, 213)); // Cambiar el color del botón 

        gbc.gridx = 0;  // Posición en la columna 0
        gbc.gridy = 4;  // Posición en la fila 4
        gbc.gridwidth = 1; // Ocupar dos columnas
        gbc.anchor = GridBagConstraints.CENTER; // Alinear al centro del panel
        panelFondo.add(BotonDatos, gbc);  // Agrega el botón de datos al panelFondo
        
        
        //propiedad del objeto GridBagLayout en que componentes se organizan en una cuadrícula 
        gbc.gridx = 0;  // Posición en la columna 0
        gbc.gridy = 3;  // Posición en la fila 3
        gbc.gridwidth = 2; // Ocupar dos columnas
        gbc.anchor = GridBagConstraints.CENTER; // Alinear al centro del panel
        panelFondo.add(botonIngresar, gbc);  // Agrega el botón de ingreso al panelFondo
        
        // Obtener las dimensiones de la pantalla
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        // Calcular las coordenadas x e y para que la ventana aparezca en el centro
        int x = (dim.width - frame.getWidth()) / 2;
        int y = (dim.height - frame.getHeight()) / 2;
        // Establecer la ubicación de la ventana en el centro de la pantalla
        frame.setLocation(x, y);
        // Agregar el panelFondo al frame en lugar del panelAutenticacion
        frame.add(panelFondo);  // Agrega el panelFondo al frame
        frame.setVisible(true);  // Hace visible el frame (ventana)
    }


    // Método para autenticar el usuario
    private boolean autenticar(String usuario, String contraseña) {
        return usuario.equals("LIGA") && contraseña.equals("2023");
    }


    // Método para mostrar la ventana del menú principal
private void mostrarVentanaMenu() {
    // Crear un JFrame para el menú principal
    JFrame menuFrame = new JFrame("Menú Principal");
    menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    menuFrame.setSize(800, 600);// tañamo
    
    menuFrame.setLocationRelativeTo(null);//centrar la ventana

    // Crear un JPanel para el menú con GridBagLayout
    JPanel panelMenu = new JPanel(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(20, 20, 20, 20); // Espaciado en todos los lados
    panelMenu.setBackground(new Color(254, 185, 249));// se define el color del panel

    // Añadir título centrado en la parte superior
    JLabel labelTitulo = new JLabel(" A CONTINUACIÓN VERÁS DATOS GENERALES DE LOS EQUIPOS DE LA LIGA FEMENINA BETPLAY 2023");  // Crea una etiqueta con el texto
    labelTitulo.setFont(new Font("Arial", Font.CENTER_BASELINE, 14));  // fuente de texto
    labelTitulo.setHorizontalAlignment(JLabel.CENTER);  // Centrar el texto horizontal
    labelTitulo.setForeground(new Color(178, 13, 78)); // Color de texto

    gbc.gridx = 0;  // Posición en la columna 0
    gbc.gridy = 0;  // Posición en la fila 0
    gbc.gridwidth = 2; // Ocupar dos columnas
    gbc.anchor = GridBagConstraints.PAGE_START; // Alinear al principio del panel
    panelMenu.add(labelTitulo, gbc);  // Agrega la etiqueta al panelMenu
    


    // Crear un JComboBox personalizado para el menú desplegable
    String[] opcionesMenu = {
        "Equipos",
        "América de Cali",
        "Independiente Santa Fe",
        "Atlético Nacional",
        "Deportivo Pereira",
        "Deportivo Cali"
    };
    
    JComboBox<String> comboBoxMenu = new JComboBox<String>(opcionesMenu);
    comboBoxMenu.setAlignmentX(Component.CENTER_ALIGNMENT); // Centrar en X
    comboBoxMenu.setPreferredSize(new Dimension(200, 40)); // Tamaño menu

    // Crear un botón para seleccionar una opción del menú
    JButton botonSeleccionar = new JButton("Seleccionar");  // Crea un botón con el texto "Seleccionar"

    botonSeleccionar.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Obtener el nombre del equipo seleccionado del JComboBox
            String nombreEquipoSeleccionado = (String) comboBoxMenu.getSelectedItem();

            // Obtener la instancia del equipo
            Equipo equipo = obtenerEquipo(nombreEquipoSeleccionado);

            // Mostrar la información del equipo
            mostrarInformacion(equipo);
        }
    });
        botonSeleccionar.setBackground(new Color(211, 136, 245)); // Cambiar el color del botón 
        

    // Crea un botón con el texto "Salir"
    JButton botonSalir = new JButton("Salir");
    
        botonSalir.addActionListener(e -> {
        JPanel panel = new JPanel(new GridLayout(4, 2)); // Cambio a GridLayout

        JLabel labelNicole = new JLabel("NICOLE DAYANA PAJARITO SANTAMARIA");
        labelNicole.setForeground(Color.BLACK);

        JLabel labelPoli = new JLabel("NICOLE.PAJARITO@PI.EDU.CO");
        labelPoli.setForeground(Color.BLACK);

        JLabel labeltel = new JLabel("https://github.com/NICOLE222215/APPLIGABETPLAY");
        labeltel.setForeground(Color.BLACK);

        panel.setBackground(new Color(172, 232, 171));
        panel.add(labelNicole);
        panel.add(labelPoli);
        panel.add(labeltel);


        JOptionPane.showMessageDialog(null, panel, "CRÉDITOS", JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    });
    botonSalir.setBackground(new Color(245, 148, 175)); // Cambiar el color del botón             

    // Agregar el JComboBox y los botones al panel usando GridBagConstraints
    gbc.gridx = 0;
    gbc.gridy = 1; // sse configura para que el indice este debajo del titulo
    panelMenu.add(comboBoxMenu, gbc);  // Agrega el JComboBox al panel en la fila 1

    gbc.gridy = 2;// Agrega el botón "Seleccionar" al panel en la fila 2
    panelMenu.add(botonSeleccionar, gbc);   
    
    gbc.gridx = 1;
    gbc.gridy = 3; // Cambia la coordenada Y para posicionar el botón en la fila 2
    gbc.anchor = GridBagConstraints.SOUTHEAST; // Alinea el componente en la esquina inferior derecha
    panelMenu.add(botonSalir, gbc);  

    // Agregar el panel al marco del menú
    menuFrame.add(panelMenu, BorderLayout.CENTER);  

    // Hacer visible el menú
    menuFrame.setVisible(true);  
}

// Método para obtener una instancia de equipo basado en el nombre
private Equipo obtenerEquipo(String nombreEquipo) {
    switch (nombreEquipo) {
        case "América de Cali":
            return new AmericaDeCali();
        case "Independiente Santa Fe":
            return new IndependienteSantaFe();
        case "Atlético Nacional":
            return new AtleticoNacional();
        case "Deportivo Pereira":
            return new DeportivoPereira();
        case "Deportivo Cali":
            return new DeportivoCali();
        default:
            return null;
    }
}

    // Método para mostrar información detallada de un equipo en un cuadro de diálogo
private void mostrarInformacion(Equipo equipo) {
    // Verificar si el equipo no es nulo
    if (equipo != null) {
        // Obtener colores para la ventana de informacion Equipos
        Color colorFondo = obtenerColorEquipo(equipo); // Color de fondo del equipo
        Color colorTexto = obtenerColorTextoEquipo(equipo); // Color del texto

        // Establecer el color de texto en el cuadro de diálogo
        UIManager.put("OptionPane.messageForeground", colorTexto);

        // Crear un cuadro de diálogo con la información del equipo
        JOptionPane optionPane = new JOptionPane(
            // Construir el mensaje con detalles del equipo
            "Información de " + equipo.getNombre() + "\n" +
            "Partidos jugados: " + equipo.getPartidosJugados() + "\n" +
            "Partidos Ganados: " + equipo.getPartidosGanados() + "\n" +
            "Partidos Empatados: " + equipo.getPartidosEmpatados() + "\n" +
            "Partidos Perdidos: " + equipo.getPartidosPerdidos() + "\n" +
            "Goles a favor: " + equipo.getGolesAFavor() + "\n" +
            "Goles en contra: " + equipo.getGolesEnContra() + "\n" +
            "Diferencia de goles: " + equipo.getDiferenciaDeGoles() + "\n" +
            "Puntos: " + equipo.getPuntos() + "\n" +
            "Goleadora destacada : " + equipo.getGoleadora() + "\n" +
            "Cantidad de goles marcados por la goleadora: " + equipo.getCantidadGolesGoleadora(),
            JOptionPane.PLAIN_MESSAGE,
            JOptionPane.DEFAULT_OPTION,
            null,
            new Object[]{"Regresar"}, // Etiqueta del botón
            null 
        );

        // Establecer el color de fondo del cuadro de diálogo
        optionPane.setBackground(colorFondo);

        // Crear y mostrar el diálogo
        JDialog dialog = optionPane.createDialog("Información del Equipo");
        dialog.setVisible(true);

        // Restaurar el color de texto por defecto
        UIManager.put("OptionPane.messageForeground", UIManager.getColor("OptionPane.messageForeground"));
    }
}


private Color obtenerColorEquipo(Equipo equipo) {
    Color colorFondo = Color.BLACK; //color fondo

    if (equipo != null) {
        switch (equipo.getNombre()) {
            case "América de Cali":
                colorFondo = new Color(255, 0, 0); 
                break;
            case "Independiente Santa Fe":
                colorFondo = new Color(255, 99, 71); 
                break;
            case "Atlético Nacional":
                colorFondo = new Color(34, 139, 34); 
                break;
            case "Deportivo Pereira":
                colorFondo = new Color(184, 134, 11);
                break;
            case "Deportivo Cali":
                colorFondo = new Color(34, 139, 34); 
                break;
            default:
                colorFondo = Color.BLACK; 
                break;
        }
    }

    // Imprimir el color en la consola
    System.out.println("Color: " + colorFondo);

    return colorFondo;
}

private Color obtenerColorTextoEquipo(Equipo equipo) {
    Color colorTexto = Color.BLACK; //Color texto

    if (equipo != null) {
        switch (equipo.getNombre()) {
            case "América de Cali":
                colorTexto = Color.RED; 
                break;
            case "Independiente Santa Fe":
                colorTexto = new Color(255, 0, 0);
                break;
            case "Atlético Nacional":
                colorTexto = new Color(34, 139, 34); 
                break;
            case "Deportivo Pereira":
                colorTexto = new Color(184, 134, 11); 
                break;
            case "Deportivo Cali":
                colorTexto = new Color(0, 128, 0);
                break;
            default:
                colorTexto = Color.BLACK; 
                break;
        }
    }

    return colorTexto;
}
}