/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ligabetplayfem2023.Controlador;

import ligabetplayfem2023.Modelo.Equipo;

/**
 *
 * @author nicol
 */
public class AtleticoNacional extends Equipo {// hereda información de clase abstracta Equipo HERENCIA
    public AtleticoNacional() {//información de los detalles del constructor 
        super("Atlético Nacional", 16, 8, 6, 2, 28, 9, 19, 30,
              "Daniela Montoya", 8);// se llama al contructor de la super clase
    }
}