/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ligabetplayfem2023.Controlador;

import ligabetplayfem2023.Modelo.Equipo;

/**
 *
 * @author nicol
 */
public class DeportivoCali extends Equipo {// hereda información de clase abstracta Equipo HERENCIA
    public DeportivoCali() {//información de los detalles del constructor 
        super("Deportivo Cali", 16, 7, 6, 3, 24, 18, 6, 27,
              "Manuela Gonzalez", 8);// se llama al contructor de la super clase
    }
}

