/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ligabetplayfem2023.Controlador;

import ligabetplayfem2023.Modelo.Equipo;

/**
 *
 * @author nicol
 */
public class IndependienteSantaFe extends Equipo {// hereda información de clase abstracta Equipo HERENCIA
    public IndependienteSantaFe() {//información de los detalles del constructor 
        super("Independiente Santa Fe", 16, 10, 5, 1, 33, 12, 35, 40,
              "Liana Salazar, Maria Reyes", 10);// se llama al contructor de la super clase
    }
}
