/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ligabetplayfem2023.Controlador;

import ligabetplayfem2023.Modelo.Equipo;

/**
 *
 * @author nicol
 */
public class DeportivoPereira extends Equipo {// hereda información de clase abstracta Equipo HERENCIA
    public DeportivoPereira() {//información de los detalles del constructor 
        super("Deportivo Pereira", 16, 8, 5, 3, 28, 20, 8, 29,
              "Ana Milé González", 8);// se llama al contructor de la super clase
    }
}
