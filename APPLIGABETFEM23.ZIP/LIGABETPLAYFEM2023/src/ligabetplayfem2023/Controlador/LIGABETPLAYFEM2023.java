/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ligabetplayfem2023.Controlador;

import ligabetplayfem2023.Vista.VentanaAutenticacion;

/**
 *
 * @author nicol
 */
    public class LIGABETPLAYFEM2023 {// clases principal
        public static void main(String[] args) {
            // Crea una nueva instancia de VentanaAutenticacion
            VentanaAutenticacion ventanaAutenticacion = new VentanaAutenticacion();
        }

    }
