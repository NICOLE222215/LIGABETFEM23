/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ligabetplayfem2023.Controlador;

import ligabetplayfem2023.Modelo.Equipo;

/**
 *
 * @author nicol
 */

public class AmericaDeCali extends Equipo {// hereda información de clase abstracta Equipo HERENCIA
    public AmericaDeCali() {//información de los detalles del constructor 
        super("América de Cali", 16, 13, 1, 2, 43, 8, 35, 40, "María Catalina Usme", 11);
    }// se llama al contructor de la super clase
}

