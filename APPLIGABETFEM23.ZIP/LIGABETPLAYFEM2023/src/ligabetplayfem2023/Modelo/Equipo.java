/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ligabetplayfem2023.Modelo;

/**
 *
 * @author nicol
 */
public abstract class Equipo {//Clase abstracta que se utiliza para que las subclases hereden atributos, es accesible desde cualquier parte del codigo
    //se crean atributos privados del equipo para almacenar información específica
    private String nombre;
    private int partidosJugados;
    private int partidosGanados;
    private int partidosEmpatados;
    private int partidosPerdidos;
    private int golesAFavor;
    private int golesEnContra;
    private int diferenciaDeGoles;
    private int puntos;
    private String goleadora;
    private int cantidadGolesGoleadora;

    // Constructor para iniciar los atributos de las clases 
    public Equipo(String nombre, int partidosJugados, int partidosGanados, int partidosEmpatados,int partidosPerdidos, int golesAFavor, int golesEnContra, int diferenciaDeGoles,
       int puntos, String goleadora, int cantidadGolesGoleadora) {
        
        this.nombre = nombre;
        this.partidosJugados = partidosJugados;
        this.partidosGanados = partidosGanados;
        this.partidosEmpatados = partidosEmpatados;
        this.partidosPerdidos = partidosPerdidos;
        this.golesAFavor = golesAFavor;
        this.golesEnContra = golesEnContra;
        this.diferenciaDeGoles = diferenciaDeGoles;
        this.puntos = puntos;
        this.goleadora = goleadora;
        this.cantidadGolesGoleadora = cantidadGolesGoleadora;
    }

    // Métodos getter para acceder a la información de los atributos. Encapsulamiento y métodos setters para modificar información de los atributos 
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPartidosJugados() {
        return partidosJugados;
    }

    public void setPartidosJugados(int partidosJugados) {
        this.partidosJugados = partidosJugados;
    }

    public int getPartidosGanados() {
        return partidosGanados;
    }

    public void setPartidosGanados(int partidosGanados) {
        this.partidosGanados = partidosGanados;
    }

    public int getPartidosEmpatados() {
        return partidosEmpatados;
    }

    public void setPartidosEmpatados(int partidosEmpatados) {
        this.partidosEmpatados = partidosEmpatados;
    }

    public int getPartidosPerdidos() {
        return partidosPerdidos;
    }

    public void setPartidosPerdidos(int partidosPerdidos) {
        this.partidosPerdidos = partidosPerdidos;
    }

    public int getGolesAFavor() {
        return golesAFavor;
    }

    public void setGolesAFavor(int golesAFavor) {
        this.golesAFavor = golesAFavor;
    }

    public int getGolesEnContra() {
        return golesEnContra;
    }

    public void setGolesEnContra(int golesEnContra) {
        this.golesEnContra = golesEnContra;
    }

    public int getDiferenciaDeGoles() {
        return diferenciaDeGoles;
    }

    public void setDiferenciaDeGoles(int diferenciaDeGoles) {
        this.diferenciaDeGoles = diferenciaDeGoles;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public String getGoleadora() {
        return goleadora;
    }

    public void setGoleadora(String goleadora) {
        this.goleadora = goleadora;
    }

    public int getCantidadGolesGoleadora() {
        return cantidadGolesGoleadora;
    }

    public void setCantidadGolesGoleadora(int cantidadGolesGoleadora) {
        this.cantidadGolesGoleadora = cantidadGolesGoleadora;
    }
}
